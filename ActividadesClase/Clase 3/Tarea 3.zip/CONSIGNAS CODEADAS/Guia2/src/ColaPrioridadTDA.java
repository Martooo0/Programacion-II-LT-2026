public interface ColaPrioridadTDA<T> {
    void inicializarCola();
    void acolarPrioridad(T x, int prioridad);
    void desacolar();
    T primero();
    int prioridad();
    boolean colaVacia();
}


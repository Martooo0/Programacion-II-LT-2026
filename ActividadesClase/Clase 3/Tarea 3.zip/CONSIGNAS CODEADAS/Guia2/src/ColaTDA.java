public interface ColaTDA<T> {
    void inicializarCola();
    void acolar(T x);
    void desacolar();
    T primero();
    boolean colaVacia();
}

public class ColaDinamica<T> implements ColaTDA<T> {
    private Nodo<T> primero;
    private Nodo<T> ultimo;

    @Override
    public void inicializarCola() {
        primero = null;
        ultimo = null;
    }

    @Override
    public void acolar(T x) {
        Nodo<T> nuevo = new Nodo<>(x);
        if (ultimo != null) {
            ultimo.siguiente = nuevo;
        }
        ultimo = nuevo;
        if (primero == null) {
            primero = ultimo;
        }
    }

    @Override
    public void desacolar() {
        if (primero != null) {
            primero = primero.siguiente;
            if (primero == null) {
                ultimo = null;
            }
        }
    }

    @Override
    public T primero() {
        return primero.dato;
    }

    @Override
    public boolean colaVacia() {
        return primero == null;
    }
}